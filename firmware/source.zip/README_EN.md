# Modi PSX Adapter — RP2040-Zero

**Modi PSX Lab 2.1:** run `lab/START.cmd`. Current application, command and center-trial instructions: [LAB_PL.md](docs/LAB_PL.md). Current validation: [VALIDATION_LAB.md](docs/VALIDATION_LAB.md). The retained basic tester below still consumes compatible RAW v1. Firmware v2 exposes four contiguous generic axes X/Y/Z/Rx, hat0–7/neutral8 and16 buttons.

Version2.1 accepts the documented00 reply header after ANALOG and preserves native RAW. USB product remains **Modi PSX Adapter**. See docs/ANALOG_BUTTON_FIX_PL.md.

Wired PS1/PS2 controller → Waveshare RP2040-Zero → generic USB HID gamepad plus
a separate vendor HID interface for WebHID/DriftGuard. USB manufacturer: Modibox.

**Status:** firmware builds and software checks are recorded in `VALIDATION.md`.
Physical RP2040 and controller observations are recorded in docs/VALIDATION_LAB.md. Firmware2.1 was flashed and both HID interfaces enumerate as bcdDevice0201. Two digital/analog cycles remained connected with zero packet errors. Exact common-sample RAW/USB equality is not proven by the non-atomic capture.
This is a private development prototype. Shared test VID/PID 1209:0001 must be
replaced before distributing/manufacturing/selling devices; see
[pid.codes](https://pid.codes/1209/0001/). It is not a Sony USB device.

## Flash and wire

1. Hold **BOOT** on the RP2040-Zero.
2. Connect its USB-C using a data cable, then release BOOT.
3. Copy `release/modi_psx_adapter_rp2040zero.uf2` onto **RPI-RP2**. The drive
   disappears and firmware starts. Unplug USB before soldering.
4. Solder six connections using `wiring.png`/`wiring.svg`. Add **4.7 kΩ DAT → 3V3**.
5. Plug the wired controller into the female PS1/PS2 socket.
6. Connect the adapter's USB-C to the PC.
7. Windows should detect **Modi PSX Adapter**. Check `Win+R → joy.cpl`.
   Standard HID requires no extra driver; actual enumeration needs hardware validation.

| PSX socket pin | Signal | Board |
|---:|---|---|
| 1 | DAT | GP13 |
| 2 | CMD | GP12 |
| 3 | Motor power | Leave disconnected |
| 4 | Ground | GND |
| 5 | Logic supply | 3V3 |
| 6 | ATT / Select | GP11 |
| 7 | CLK | GP10 |
| 8 | Unused for supported pads | Leave disconnected |
| 9 | ACK | Leave disconnected in MVP |

Board drawing: component side, USB-C at top; GP13/12/11/10 on bottom edge,
GND/3V3 on left. Female socket viewed looking into the mating face: **9…1**;
rear solder view is mirrored: **1…9**. Verify continuity with a multimeter.
Diagram colors identify signals, not extension-cable wire colors. Do not connect
motor pin 3 to USB 5 V. Do not connect to a powered console simultaneously.
DAT stays an input; external pull-up is required. Motor supply remains disconnected; the terminal can send mappings and values but does not supply motor power.

## Raw tester

From the project directory: `python tools/serve_tester.py`. From `release/`:
`python serve_tester.py`. Open [localhost](http://localhost:8000) in Chrome/Edge,
press **POŁĄCZ ADAPTER** (connect), and select Modi PSX Adapter. Keep sticks at
rest for one second; then move through full circles and test buttons/pressure.
The Polish UI displays RAW axes, measured rest center, min/max, range, 1-second
peak-to-peak jitter and standard deviation, distance, XY trails, 36-sector circle
coverage, all 12 DS2 pressure values, received report rate and frame errors.
DEMO generates clearly marked synthetic data; it is not a hardware test.

**RESET MEASUREMENTS** clears application statistics only. **ZAPISZ ŚRODEK**
(capture center) records a 1-second mean as a local reference only. Neither sends
anything to the pad. RAW values are never filtered, centered, scaled, smoothed,
dead-zoned or corrected. Example RX/RY/LX/LY `124/130/121/133` stays identical.
RAW is the controller's wire output, after any internal processing in that pad.
Jitter measurements require sticks at rest. Reconnection starts new statistics.

Supported IDs: 41 digital, 53 Dual Analog/analog joystick, 73 DualShock analog,
79 DS2 pressure, F3 temporary config. ID 41/73 alone cannot prove physical model;
DS2 can use either without pressure. Family labels describe observed protocol;
ID 79 latches DS2 capability until disconnection. See `DRIFTGUARD_PROTOCOL.md`.
No multitap, wireless, neGcon, Mouse, GunCon or JogCon support in this MVP.
The JSON profile is a proposed integration format, not an already installed
DriftGuard driver. Integrating a particular DriftGuard application needs its code.

## Rebuild with one command

Install Python 3.10+ and run from the project root:

```text
python build.py
```

Windows x64 bootstrap downloads portable ARM GCC 15.2.1, CMake 3.31.6, Ninja 1.12.1
and pioasm 2.2.0 from pinned official archives, verifying SHA256. Allow approximately
2 GB disk space and Internet for the first run. It changes no system installation;
tools/build files are local `.tools/` and `.build/`. SDK 2.2.0 and TinyUSB sources
are vendored. Output is `release/`. Linux/macOS require tools installed on PATH;
automatic bootstrap is Windows x64 only. `python build.py --help` lists options.
Assigned USB IDs: `python build.py --vid 0xNNNN --pid 0xNNNN` with your own numbers.

Parser tests: `python tests/run_tests.py --cc gcc` (or clang), or on Windows
`python tests/run_tests.py --zig C:/path/zig.exe`. Tester tests require Node.js:
`node tests/test_tester.js`. Verify built ELF/descriptors/UF2 with
`python tests/verify_firmware.py`.

Unresponsive pad: check socket orientation, data cable, common ground, 3V3 supply,
GPIO numbers and pull-up; wait several seconds for configuration. DS1 has no
pressure. DS2/clones may reject pressure mode; inspect ID and flags. Short wires
help prevent electrical corruption. PSX has no checksum, so plausible corrupt
axis bytes are not automatically detectable. No filtering hides these faults.
See `VALIDATION.md` for the remaining physical acceptance checklist.

## Licensing and credits

Modi sources: Apache-2.0. PIO/DMA transport and configuration derived from
[Joypad OS](https://github.com/joypad-ai/joypad-os), pinned commit
`bf507bf87aee18e24ea82f84647cd592a7a2ddaf`. `NOTICE` lists modifications.
Pico SDK: BSD-3-Clause; TinyUSB: MIT, with additional file-level licenses retained
in vendored sources. No GPL PicoGamepadConverter code copied.
Board reference: [Waveshare schematic](https://files.waveshare.com/upload/4/4c/RP2040_Zero.pdf).
Socket numbering: [PSX-SPX](https://psx-spx.consoledev.net/ps1/pinouts/controller-ports-and-memory-card-ports/).
