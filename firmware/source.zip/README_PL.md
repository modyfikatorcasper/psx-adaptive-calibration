# Modi PSX Adapter — RP2040-Zero

**Badania centrowania zakończone 11 października 2026:** [pełny raport o adaptacyjnej kalibracji PS1 i PS2](docs/ADAPTIVE_CALIBRATION_PL.md), [tekst do publikacji](docs/ADAPTIVE_CALIBRATION_POST_PL.md) oraz [pakiet dowodowy](docs/research/center-2026-10-11/evidence.json).

**Wersja Modi PSX Lab 2.1:** uruchom `lab/START.cmd`; instrukcje terminala, logu i badania środka są w [LAB_PL.md](docs/LAB_PL.md). Aktualną walidację opisuje [VALIDATION_LAB.md](docs/VALIDATION_LAB.md). Zachowany prosty tester niżej używa RAW v1; firmware v2 nadal go obsługuje. Gamepad v2: LX/LY/RX/RY jako X/Y/Z/Rx, hat0–7/neutral8 oraz16 przycisków.

Poprawka2.1 przyjmuje udokumentowany nagłówek00 po ANALOG i zachowuje oryginalne RAW. Szczegóły: [ANALOG_BUTTON_FIX_PL.md](docs/ANALOG_BUTTON_FIX_PL.md). Nazwa urządzenia USB: **Modi PSX Adapter**.

Firmware prototypu: przewodowy pad PS1/PS2 → Waveshare RP2040-Zero → USB gamepad
i osobny interfejs RAW dla WebHID/DriftGuard. Producent USB: Modibox.

**Status:** firmware skompilowany; testy programowe opisuje `VALIDATION.md`.
Wykonano pomiary na fizycznym RP2040 i padach; zakres dowodów opisuje docs/VALIDATION_LAB.md. Firmware2.1 wgrano i potwierdzono przez USB bcdDevice0201. Test ANALOG2.1 potwierdził przełączenia41/73 bez utraty połączenia i przycisków. To pakiet do prywatnych testów. Testowy VID/PID
1209:0001 jest wspólny i wymaga zastąpienia przy dystrybucji urządzenia.

## Wgranie i podłączenie — 7 kroków

1. Przytrzymaj **BOOT** na RP2040-Zero.
2. Podłącz RP2040-Zero przewodem USB-C z transmisją danych; zwolnij BOOT.
3. Na dysk **RPI-RP2** skopiuj `modi_psx_adapter_rp2040zero.uf2` z `release/`.
   Dysk zniknie, a płytka uruchomi firmware. Następnie odłącz USB.
4. Przylutuj sześć przewodów według `wiring.png` / `wiring.svg` i poniższej mapy.
   Dodaj rezystor **4,7 kΩ między DAT i 3V3**. Lutuj bez zasilania.
5. Podłącz przewodowy kontroler do żeńskiego gniazda PS1/PS2.
6. Podłącz USB-C płytki do PC.
7. Windows powinien wykryć **Modi PSX Adapter**, z urządzeniem HID gamepad.
   Sprawdź w `Win+R → joy.cpl`. Nie potrzeba dodatkowego sterownika.

## Mapa połączeń

| Pin gniazda PSX | Sygnał | RP2040-Zero |
|---:|---|---|
| 1 | DAT: pad → adapter | GP13 |
| 2 | CMD: adapter → pad | GP12 |
| 3 | Zasilanie silników | Nie podłączaj |
| 4 | Masa | GND |
| 5 | Zasilanie logiki | 3V3 |
| 6 | ATT / Select | GP11 |
| 7 | CLK | GP10 |
| 8 | NC dla obsługiwanych padów | Nie podłączaj |
| 9 | ACK | Nie podłączaj w MVP |

Płytka na ilustracji: widok od komponentów, USB-C u góry. GP13/12/11/10 są na
dolnej krawędzi; 3V3 i GND na lewej. **Żeńskie gniazdo oglądane od strony
wkładania wtyczki ma kolejność 9…1; widok od tyłu jest lustrzany: 1…9.**
Sprawdź ciągłość multimetrem. Kolory w ilustracji są oznaczeniami sygnałów,
nie standardem kolorów przewodów w przedłużaczu. Nie łącz PSX pinu 3 z USB 5 V.
Nie podłączaj adaptera równocześnie do zasilanej konsoli. Zasilanie motorów pozostaje odłączone; terminal może wysyłać mapę i wartości, ale nie dodaje zasilania motorów.

## Tester RAW

W katalogu projektu uruchom `python tools/serve_tester.py`; w samym katalogu
`release/` użyj `python serve_tester.py`. Otwórz [tester](http://localhost:8000)
w Chrome lub Edge. Kliknij **POŁĄCZ ADAPTER** i wybierz Modi PSX Adapter.
Pozostaw gałki w spoczynku przez 1 s, potem wykonaj pełne okręgi i naciskaj
przyciski. Dla DS2 po konfiguracji powinien pojawić się ID 79 i 12 nacisków.
Przycisk DEMO pokazuje wyłącznie dane syntetyczne, co jest zaznaczone na ekranie.

Tester pokazuje osie 0–255, centrum spoczynkowe jako lokalne odniesienie,
min/max, zakres, jitter p-p i σ w oknie 1 s, odległość, XY, ślad, pokrycie
36 sektorów oraz naciski, rate i błędy. **RESET MEASUREMENTS** resetuje statystyki.
**ZAPISZ ŚRODEK** zapisuje średnią spoczynku tylko do statystyk. Oba przyciski
nie wysyłają kalibracji. Jitter mierz bez ruchu; zakres i circle test podczas
ruchu. Odłączanie/podłączanie kontrolera automatycznie rozpoczyna nowe statystyki.

RAW zachowuje odczyt kontrolera, np. RX/RY/LX/LY `124/130/121/133`, bez deadzone,
anti-drift, filtrowania i rozciągania zakresu. Po błędnym odczycie flaga ważności
jest wyłączona; ostatniej poprawnej ramki nie wolno liczyć jako nowej próbki.
Sam kontroler może przetwarzać dane wewnętrznie — RAW oznacza dane na przewodzie.
Automatyczne przełączenie w analog/pressure nie jest kalibracją gałek.

ID 41 może być też DualShockiem w trybie cyfrowym, a 73 — DS2 bez nacisków.
Etykieta rodziny opisuje obserwowany protokół; nie identyfikuje pewnie modelu
lub autentyczności. 79 potwierdza tryb pressure DS2. Brak obsługi multitap,
neGcon, Mouse, GunCon, JogCon i padów bezprzewodowych w tym MVP.
Profil JSON jest propozycją integracji; istniejący DriftGuard wymaga użycia
opisanego protokołu w swoim kodzie.

## Odtworzenie firmware jednym poleceniem

Zainstaluj Python 3.10+ i w katalogu projektu uruchom:

```powershell
python build.py
```

Windows x64: skrypt pobiera przenośne ARM GCC 15.2.1, CMake 3.31.6,
Ninja 1.12.1 i pioasm 2.2.0 z przypiętych źródeł i sprawdza SHA256 archiwów.
Nie zmienia instalacji systemowych. Pierwszy raz potrzebuje Internetu i ok.
2 GB wolnego miejsca; później może działać offline. Pico SDK 2.2.0 i TinyUSB
są w `vendor/`. Wynik trafia do `release/`; `.tools/` i `.build/` to pliki robocze.
Na Linux/macOS zainstaluj te narzędzia na PATH; tam bootstrap nie jest automatyczny.
Zaawansowane opcje: `python build.py --help`. Dla przypisanego VID/PID użyj
`--vid 0xNNNN --pid 0xNNNN`, zastępując N właściwymi cyframi.

Testy: `python tests/run_tests.py --cc gcc` lub `--cc clang`; na Windows można
użyć `--zig C:/sciezka/zig.exe`. Testy testera wymagają Node.js:
`node tests/test_tester.js`. Test skompilowanego UF2: `python tests/verify_firmware.py`.

## Gdy coś nie działa

Brak RPI-RP2: odłącz USB, trzymaj BOOT przed podłączeniem, użyj przewodu danych.
Gamepad widoczny, ale pad odłączony: sprawdź widok gniazda, 3V3, wspólną masę,
ciągłość DAT/CMD, pull-up 4,7 kΩ, CLK10/ATT11. Nie podłączaj ACK do 5 V.
Brak analogów: odczekaj konfigurację (~kilka sekund), spróbuj przycisku ANALOG.
Brak pressure: DS1 go nie ma; DS2/clony mogą odrzucać 4F. ID 73 nie daje
podstaw do wymyślania nacisków. Błędy przy krańcach: skróć przewody, sprawdź
lutowanie/pull-up i zasilanie. PSX nie ma sumy kontrolnej, więc nie każdy błąd
elektryczny można wykryć. Firmware nie naprawia odczytów filtrem.

## Licencje i źródła

Kod Modi: Apache-2.0; host PIO/DMA i konfiguracja pochodzą z
[Joypad OS](https://github.com/joypad-ai/joypad-os), commit
`bf507bf87aee18e24ea82f84647cd592a7a2ddaf`. `NOTICE` opisuje modyfikacje.
Pico SDK: BSD-3-Clause; TinyUSB: MIT, z dodatkowymi licencjami własnych plików.
Zachowane źródła/licencje są w `vendor/`. Kod PicoGamepadConverter nie był kopiowany.
Mapa płytki: [Waveshare](https://www.waveshare.com/wiki/RP2040-Zero);
[schemat producenta](https://files.waveshare.com/upload/4/4c/RP2040_Zero.pdf).
Numeracja PSX: [PSX-SPX](https://psx-spx.consoledev.net/ps1/pinouts/controller-ports-and-memory-card-ports/).
