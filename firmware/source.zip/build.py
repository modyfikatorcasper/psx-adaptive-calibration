"""One-command firmware build. Windows x64 bootstrap uses pinned official archives.
Run: python build.py. Python 3.10+ required. SDK and TinyUSB sources are vendored.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
ASSETS = {
    'arm': ('https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v15.2.1-1.1/xpack-arm-none-eabi-gcc-15.2.1-1.1-win32-x64.zip', 'bae6a3d1667697ce750c3b13d6d26d80973ecedc2cc87bf04869e83447fd93ea', 'xpack-arm-none-eabi-gcc-15.2.1-1.1/bin/arm-none-eabi-gcc.exe'),
    'cmake': ('https://github.com/Kitware/CMake/releases/download/v3.31.6/cmake-3.31.6-windows-x86_64.zip', 'd163cd3ab4959b0a53fa8988f2ddbd2e6c501658201e6a154386bad9dbe4f836', 'cmake-3.31.6-windows-x86_64/bin/cmake.exe'),
    'ninja': ('https://github.com/ninja-build/ninja/releases/download/v1.12.1/ninja-win.zip', 'f550fec705b6d6ff58f2db3c374c2277a37691678d6aba463adcbb129108467a', 'ninja/ninja.exe'),
    'pioasm': ('https://github.com/raspberrypi/pico-sdk-tools/releases/download/v2.2.0-2/pico-sdk-tools-2.2.0-x64-win.zip', '470fb7f8f8d6aa83ab320aead6d7b6166858d984798857bfb2cc53e58e79bd37', 'pico-tools/pioasm/pioasm.exe'),
}
def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def bootstrap(name, base):
    url, expected, relative = ASSETS[name]
    exe = base / relative
    if exe.exists():
        return str(exe)
    base.mkdir(parents=True, exist_ok=True)
    archive = base / (name + '.zip')
    if not archive.exists() or digest(archive) != expected:
        print('Downloading', name, 'from', url, flush=True)
        urllib.request.urlretrieve(url, archive)
    if digest(archive) != expected:
        raise RuntimeError('SHA256 mismatch: ' + name)
    target = base / ('ninja' if name == 'ninja' else 'pico-tools' if name == 'pioasm' else '')
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            path = (target / info.filename).resolve()
            if not path.is_relative_to(target.resolve()):
                raise RuntimeError('Archive path escape')
        z.extractall(target)
    if not exe.exists():
        raise RuntimeError('Missing executable after extraction: ' + str(exe))
    return str(exe)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tools-root', type=Path, default=ROOT/'.tools')
    parser.add_argument('--build-dir', type=Path, default=ROOT/'.build')
    parser.add_argument('--vid', default='0x1209')
    parser.add_argument('--pid', default='0x0001')
    args = parser.parse_args()
    ids = [int(args.vid, 0), int(args.pid, 0)]
    if not all(1 <= i <= 0xFFFF for i in ids):
        parser.error('VID/PID must be nonzero 16-bit assigned identifiers')
    if ids == [0x1209, 1]:
        print('PRIVATE IN-HOUSE TEST BUILD: 1209:0001 is not unique and cannot be used on distributed devices.', flush=True)
    base = args.tools_root.resolve()
    commands = {}
    for name, command in [('arm', 'arm-none-eabi-gcc'), ('cmake', 'cmake'), ('ninja', 'ninja'), ('pioasm', 'pioasm')]:
        existing = base / ASSETS[name][2]
        found = str(existing) if existing.exists() else shutil.which(command)
        if not found:
            if platform.system() != 'Windows' or platform.machine().lower() not in ('amd64', 'x86_64'):
                raise RuntimeError('Install ARM GCC, CMake, Ninja and pioasm 2.2.0+ on PATH; automatic download is Windows x64 only')
            found = bootstrap(name, base)
        commands[name] = found
    env = os.environ.copy()
    env['PATH'] = str(Path(commands['arm']).parent) + os.pathsep + env.get('PATH', '')
    build = args.build_dir.resolve()
    configure = [commands['cmake'], '-S', str(ROOT), '-B', str(build), '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DPICO_BOARD=waveshare_rp2040_zero',
        '-DCMAKE_MAKE_PROGRAM='+commands['ninja'], '-DMODI_PIOASM='+commands['pioasm'],
        '-DPython3_EXECUTABLE='+sys.executable, '-DPICO_TOOLCHAIN_PATH='+str(Path(commands['arm']).parent.parent),
        '-DMODI_USB_VID='+hex(ids[0]), '-DMODI_USB_PID='+hex(ids[1])]
    subprocess.run(configure, check=True, env=env)
    subprocess.run([commands['cmake'], '--build', str(build), '--parallel', '6'], check=True, env=env)
    release = ROOT/'release'
    release.mkdir(exist_ok=True)
    for suffix in ('uf2', 'elf', 'bin', 'elf.map'):
        path = build/('modi_psx_adapter_rp2040zero.'+suffix)
        if path.exists():
            shutil.copy2(path, release/path.name)
    for name in ('README_PL.md','README_EN.md','DRIFTGUARD_PROTOCOL.md','driftguard-device-profile.json','NOTICE','LICENSE','VALIDATION.md'):
        if (ROOT/name).exists(): shutil.copy2(ROOT/name,release/name)
    # Directly usable server next to the standalone release HTML.
    for name in ('wiring.svg','wiring.png'):
        if (ROOT/'assets'/name).exists():
            shutil.copy2(ROOT/'assets'/name,release/name)
    versions = {name: subprocess.check_output([exe, '--version'], env=env, text=True).splitlines()[0]
                for name,exe in commands.items() if name != 'pioasm'}
    manifest = {'board':'waveshare_rp2040_zero','flash_bytes':2097152,'usb_vid':hex(ids[0]),'usb_pid':hex(ids[1]),
                'joypad_os_commit':'bf507bf87aee18e24ea82f84647cd592a7a2ddaf','pico_sdk':'2.2.0',
                'tinyusb_commit':'86ad6e56c1700e85f1c5678607a762cfe3aa2f47','tools':versions,
                'uf2_sha256':digest(release/'modi_psx_adapter_rp2040zero.uf2')}
    (release/'build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print('Built',release/'modi_psx_adapter_rp2040zero.uf2',flush=True)

if __name__ == '__main__':
    main()
