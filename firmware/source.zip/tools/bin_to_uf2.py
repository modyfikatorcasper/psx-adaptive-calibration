"""Convert a linked RP2040 flash binary to genuine family-tagged UF2 blocks."""
from pathlib import Path
import struct
import sys

def convert(source, target):
    data = Path(source).read_bytes()
    if not 256 <= len(data) <= 2 * 1024 * 1024:
        raise ValueError('Binary must contain boot2 and fit 2 MB flash')
    count = (len(data) + 255) // 256
    with Path(target).open('wb') as out:
        for i in range(count):
            payload = data[i*256:(i+1)*256].ljust(256, b'\0')
            out.write(struct.pack('<8I', 0x0A324655, 0x9E5D5157, 0x2000,
                                  0x10000000+i*256, 256, i, count, 0xE48BFF56))
            out.write(payload + bytes(220) + struct.pack('<I', 0x0AB16F30))
    print(f'UF2: {count} blocks, {Path(target).stat().st_size} bytes')

if __name__ == '__main__':
    convert(*sys.argv[1:])
